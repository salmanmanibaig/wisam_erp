<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class CpoComAgent extends Model
{
    
}
