<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class CpoTerm extends Model
{
    
}
