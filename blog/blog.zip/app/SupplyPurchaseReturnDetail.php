<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SupplyPurchaseReturnDetail extends Model
{
    protected $table = 'supply_purchase_return_details';
}
