<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use OwenIt\Auditing\Contracts\Auditable;

class Inward extends Model
{
//    use \OwenIt\Auditing\Auditable;
}
