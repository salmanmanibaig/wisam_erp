<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class CustomerPurchaseTerm extends Model
{
    
}
