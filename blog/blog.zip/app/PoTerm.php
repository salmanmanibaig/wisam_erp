<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class PoTerm extends Model
{
    
}
