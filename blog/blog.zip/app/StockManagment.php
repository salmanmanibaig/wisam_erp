<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StockManagment extends Model
{
    //
}
