<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VendorBlNumber extends Model
{
    //
}
