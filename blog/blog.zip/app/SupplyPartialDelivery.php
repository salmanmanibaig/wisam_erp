<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SupplyPartialDelivery extends Model
{
    protected $table = 'supply_partial_deliveries';
}
