<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class CustomerPurchaseOrderExpense extends Model
{
    
}
