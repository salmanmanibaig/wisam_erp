<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class PurchaseTerm extends Model
{
    
}
